// cc_checkin.dart — pixel-accurate to Image 3
import 'package:flutter/material.dart';
import 'cc_theme.dart';

class CheckinTab extends StatefulWidget {
  const CheckinTab({super.key});
  @override
  State<CheckinTab> createState() => _S();
}

class _S extends State<CheckinTab> with SingleTickerProviderStateMixin {
  bool _done = false;
  late AnimationController _ac;
  late Animation<double> _sc;
  // M T W T F S S — first 4 checked, last 3 not
  final _hist = [true, true, true, true, false, false, false];

  @override
  void initState() {
    super.initState();
    _ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _sc = Tween(begin: 1.0, end: 1.05)
      .animate(CurvedAnimation(parent: _ac, curve: Curves.elasticOut));
    _ac.addStatusListener((s) { if (s == AnimationStatus.completed) _ac.reverse(); });
  }

  @override
  void dispose() { _ac.dispose(); super.dispose(); }

  int get _streak => _hist.where((v) => v).length + (_done ? 1 : 0);

  @override
  Widget build(BuildContext context) {
    final e = context.elder;
    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 32),
          children: [
            // Title — Image 3
            Text('Daily Check-in', style: TextStyle(
              fontSize: context.fs(C.fTitle),
              fontWeight: FontWeight.w900, color: C.textDark)),
            const SizedBox(height: 4),
            Text('Keep your family circle updated.', style: TextStyle(
              fontSize: context.fs(C.fSub), color: C.textMid)),

            const SizedBox(height: 24),

            // Circular streak indicator — Image 3
            CC(
              pad: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
              child: Center(child: SizedBox(
                width: e ? 180 : 150, height: e ? 180 : 150,
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox.expand(child: CircularProgressIndicator(
                    value: _streak / 14.0,
                    strokeWidth: 10,
                    backgroundColor: C.divider,
                    color: C.primary,
                    strokeCap: StrokeCap.round,
                  )),
                  Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.local_fire_department_rounded,
                      color: C.fire, size: e ? 34 : 28),
                    Text('$_streak', style: TextStyle(
                      fontSize: context.fs(e ? 52 : 44),
                      fontWeight: FontWeight.w900, color: C.textDark, height: 1.0)),
                    Text('DAY STREAK', style: TextStyle(
                      fontSize: context.fs(C.fCap), color: C.textMid,
                      fontWeight: FontWeight.w700, letterSpacing: 1)),
                  ]),
                ]),
              )),
            ),

            const SizedBox(height: 16),

            // 7-day dots — Image 3 (M T W T F S S)
            CC(
              pad: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: ['M','T','W','T','F','S','S'].asMap().entries.map((en) {
                  final ok = _hist[en.key];
                  return Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(en.value, style: TextStyle(
                      fontSize: context.fs(C.fSub),
                      fontWeight: FontWeight.w700, color: C.textLight)),
                    const SizedBox(height: 8),
                    Container(
                      width: e ? 16 : 13, height: e ? 16 : 13,
                      decoration: BoxDecoration(
                        color: ok ? C.primary : Colors.transparent,
                        border: Border.all(
                          color: ok ? C.primary : C.textLight, width: 2),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ]);
                }).toList(),
              ),
            ),

            const SizedBox(height: 16),

            // I AM OKAY button — Image 3
            ScaleTransition(scale: _sc, child: _done
              ? CC(
                  bg: C.greenSoft,
                  pad: const EdgeInsets.symmetric(vertical: 36),
                  child: Column(children: [
                    Icon(Icons.check_circle_rounded, color: C.green, size: e ? 60 : 50),
                    const SizedBox(height: 14),
                    Text('CHECKED IN!', style: TextStyle(
                      fontSize: context.fs(C.fH2),
                      fontWeight: FontWeight.w900, color: C.green,
                      letterSpacing: 1.5)),
                    const SizedBox(height: 5),
                    Text('Your family has been notified', style: TextStyle(
                      fontSize: context.fs(C.fSub), color: C.textMid)),
                  ]),
                )
              : GestureDetector(
                  onTap: () { setState(() => _done = true); _ac.forward(); },
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: e ? 40 : 34),
                    decoration: BoxDecoration(
                      color: C.primary,
                      borderRadius: BorderRadius.circular(18)),
                    child: Column(children: [
                      Icon(Icons.favorite_outline_rounded,
                        color: Colors.white, size: e ? 60 : 50),
                      const SizedBox(height: 14),
                      Text('I AM OKAY', style: TextStyle(
                        fontSize: context.fs(C.fH2),
                        fontWeight: FontWeight.w900, color: Colors.white,
                        letterSpacing: 2.5)),
                      const SizedBox(height: 6),
                      Text('TAP TO NOTIFY FAMILY', style: TextStyle(
                        fontSize: context.fs(C.fCap),
                        color: Colors.white70, letterSpacing: 1.5,
                        fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
            ),

            const SizedBox(height: 16),

            // Info note — Image 3
            CC(
              bg: C.bg,
              pad: const EdgeInsets.all(14),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(Icons.info_outline_rounded, color: C.textLight, size: 18),
                const SizedBox(width: 10),
                Expanded(child: Text(
                  'Missed check-ins for 7 consecutive days will automatically trigger an alert to your family monitors.',
                  style: TextStyle(
                    fontSize: context.fs(C.fSub),
                    color: C.textMid, height: 1.5))),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}