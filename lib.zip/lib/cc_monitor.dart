// cc_monitor.dart — pixel-accurate to Image 5
import 'package:flutter/material.dart';
import 'cc_theme.dart';
import 'models/mock_data.dart';
import 'member_detail.dart';
import 'cc_invite.dart';

class MonitorTab extends StatelessWidget {
  const MonitorTab({super.key});

  @override
  Widget build(BuildContext context) {
    final e = context.elder;
    final members = MockData.familyMembers;
    final missed = members.where((m) => !m.checkedInToday).toList();

    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 32),
          children: [
            // Header row — Image 5
            Row(crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Monitor', style: TextStyle(
                  fontSize: context.fs(C.fTitle),
                  fontWeight: FontWeight.w900, color: C.textDark)),
                Text('YOUR FAMILY CIRCLE', style: TextStyle(
                  fontSize: context.fs(C.fCap), color: C.textMid,
                  fontWeight: FontWeight.w800, letterSpacing: 1.2)),
              ]),
              GestureDetector(
                onTap: () => showModalBottomSheet(
                  context: context, isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (_) => const InviteSheet()),
                child: Container(
                  width: e ? 46 : 40, height: e ? 46 : 40,
                  decoration: BoxDecoration(
                    color: C.primarySoft, shape: BoxShape.circle),
                  child: Icon(Icons.person_add_outlined,
                    color: C.primary, size: e ? 22 : 18),
                ),
              ),
            ]),
            const SizedBox(height: 16),

            // Chips row — Image 5
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _chip('${members.length} MEMBERS', null, context),
                const SizedBox(width: 8),
                _chip('${members.where((m) => m.checkedInToday).length} CHECKED-IN',
                  C.green, context),
                if (missed.isNotEmpty) ...[
                  const SizedBox(width: 8),
                  _chip('${missed.length} MISSED', C.orange, context),
                ],
              ]),
            ),
            const SizedBox(height: 14),

            // Warning banner — Image 5
            if (missed.isNotEmpty) ...[
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: C.orangeSoft,
                  borderRadius: BorderRadius.circular(12)),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.info_outline_rounded, color: C.orange, size: 20),
                  const SizedBox(width: 10),
                  Expanded(child: Text(
                    "${missed.map((m) => m.name).join(', ')} hasn't checked in yet today.",
                    style: TextStyle(
                      fontSize: context.fs(C.fSub),
                      color: C.textDark, fontWeight: FontWeight.w600))),
                ]),
              ),
              const SizedBox(height: 14),
            ],

            const CapLabel('FAMILY MEMBERS'),
            const SizedBox(height: 10),

            // Member cards — Image 5
            ...members.map((m) => _MemberCard(
              member: m, elder: e,
              onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => MemberDetailScreen(member: m))),
            )),

            const SizedBox(height: 8),

            // Add a person dashed row — Image 5
            GestureDetector(
              onTap: () => showModalBottomSheet(
                context: context, isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (_) => const InviteSheet()),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: C.textLight, style: BorderStyle.solid, width: 1.5)),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.people_outline_rounded, color: C.textLight, size: e ? 22 : 18),
                  const SizedBox(width: 10),
                  Text('ADD A PERSON', style: TextStyle(
                    fontSize: context.fs(C.fSub),
                    fontWeight: FontWeight.w800, color: C.textLight, letterSpacing: 1)),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, Color? color, BuildContext ctx) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
    decoration: BoxDecoration(
      color: (color ?? C.primary).withOpacity(0.1),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: (color ?? C.primary).withOpacity(0.3))),
    child: Text(label, style: TextStyle(
      fontSize: ctx.fs(C.fCap),
      fontWeight: FontWeight.w800,
      color: color ?? C.primary,
      letterSpacing: 0.5)));
}

class _MemberCard extends StatelessWidget {
  final MockFamilyMember member;
  final bool elder;
  final VoidCallback onTap;
  const _MemberCard({required this.member, required this.elder, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final ago = DateTime.now().difference(member.lastSeen);
    final agoText = ago.inMinutes < 60 ? '${ago.inMinutes}M AGO' : '${ago.inHours}H AGO';
    final medsDone = member.medicines.where((m) => m.takenToday).length;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Stack(children: [
              CircleAvatar(
                radius: elder ? 28 : 24,
                backgroundColor: member.avatarColor.withOpacity(0.2),
                child: Text(member.avatarInitials, style: TextStyle(
                  color: member.avatarColor,
                  fontWeight: FontWeight.w900,
                  fontSize: context.fs(elder ? 16 : 14))),
              ),
              Positioned(right: 0, bottom: 0, child: Container(
                width: elder ? 14 : 12, height: elder ? 14 : 12,
                decoration: BoxDecoration(
                  color: member.checkedInToday ? C.green : C.orange,
                  shape: BoxShape.circle,
                  border: Border.all(color: C.surface, width: 2)),
              )),
            ]),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(member.name, style: TextStyle(
                fontSize: context.fs(C.fH3),
                fontWeight: FontWeight.w900, color: C.textDark)),
              const SizedBox(height: 2),
              Row(children: [
                Icon(Icons.location_on_outlined,
                  size: context.fs(12), color: C.textMid),
                const SizedBox(width: 2),
                Flexible(child: Text(
                  '${member.locationLabel} · $agoText',
                  style: TextStyle(
                    fontSize: context.fs(C.fSub), color: C.textMid),
                  overflow: TextOverflow.ellipsis)),
              ]),
            ])),
            Icon(Icons.chevron_right_rounded, color: C.textLight, size: elder ? 24 : 20),
          ]),
          const SizedBox(height: 12),
          // Status badges — Image 5
          Row(children: [
            _badge(
              member.checkedInToday ? 'CHECKED IN' : 'NOT CHECKED',
              member.checkedInToday ? C.green : C.orange,
              context),
            const SizedBox(width: 8),
            _badge('${medsDone}/${member.medicines.length} MEDS', C.textMid, context),
            const SizedBox(width: 8),
            Row(children: [
              Icon(Icons.local_fire_department_rounded,
                color: C.fire, size: elder ? 17 : 15),
              const SizedBox(width: 2),
              Text('${member.streakDays}', style: TextStyle(
                fontSize: context.fs(C.fSub),
                fontWeight: FontWeight.w900, color: C.fire)),
            ]),
          ]),
        ]),
      ),
    );
  }

  Widget _badge(String label, Color color, BuildContext ctx) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: color.withOpacity(0.12),
      borderRadius: BorderRadius.circular(6)),
    child: Text(label, style: TextStyle(
      fontSize: ctx.fs(C.fCap),
      fontWeight: FontWeight.w800, color: color)));
}