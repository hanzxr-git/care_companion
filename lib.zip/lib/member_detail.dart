// cc_member_detail.dart — Images 6,7,8,9
import 'package:flutter/material.dart';
import 'cc_theme.dart';
import 'models/mock_data.dart';

class MemberDetailScreen extends StatefulWidget {
  final MockFamilyMember member;
  const MemberDetailScreen({super.key, required this.member});
  @override
  State<MemberDetailScreen> createState() => _S();
}

class _S extends State<MemberDetailScreen> with SingleTickerProviderStateMixin {
  late TabController _tc;
  @override
  void initState() { super.initState(); _tc = TabController(length: 4, vsync: this); }
  @override
  void dispose() { _tc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final e = context.elder;
    final m = widget.member;
    return Scaffold(
      backgroundColor: C.bg,
      appBar: AppBar(
        backgroundColor: C.bg,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, size: e ? 22 : 18, color: C.textDark),
          onPressed: () => Navigator.pop(context)),
        title: Text(m.name, style: TextStyle(
          fontSize: context.fs(C.fH2),
          fontWeight: FontWeight.w900, color: C.textDark)),
        bottom: TabBar(
          controller: _tc,
          labelColor: C.primary,
          unselectedLabelColor: C.textLight,
          indicatorColor: C.primary,
          indicatorWeight: 2.5,
          indicatorSize: TabBarIndicatorSize.label,
          labelStyle: TextStyle(fontFamily: 'Nunito',
            fontSize: context.fs(C.fCap),
            fontWeight: FontWeight.w800, letterSpacing: 0.5),
          unselectedLabelStyle: TextStyle(fontFamily: 'Nunito',
            fontSize: context.fs(C.fCap), fontWeight: FontWeight.w600),
          tabs: const [
            Tab(icon: Icon(Icons.location_on_outlined, size: 20), text: 'LOCATION'),
            Tab(icon: Icon(Icons.local_fire_department_outlined, size: 20), text: 'STREAK'),
            Tab(icon: Icon(Icons.medication_outlined, size: 20), text: 'MEDS'),
            Tab(icon: Icon(Icons.calendar_today_outlined, size: 20), text: 'EVENTS'),
          ],
        ),
      ),
      body: TabBarView(controller: _tc, children: [
        _LocTab(m: m, e: e),
        _StrTab(m: m, e: e),
        _MedTab(m: m, e: e),
        _EvTab(m: m, e: e),
      ]),
    );
  }
}

class _LocTab extends StatelessWidget {
  final MockFamilyMember m; final bool e;
  const _LocTab({required this.m, required this.e});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
    children: [
      // Map card — Image 6
      CC(
        pad: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(children: [
            Container(
              height: e ? 230 : 200,
              color: C.primarySoft,
              child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.map_outlined, size: e ? 48 : 40,
                  color: C.primary.withOpacity(0.25)),
                const SizedBox(height: 8),
                Text('MAP VIEW PLACEHOLDER', style: TextStyle(
                  fontSize: context.fs(C.fCap), color: C.textMid,
                  fontWeight: FontWeight.w700, letterSpacing: 1)),
              ])),
            ),
            // LIVE NOW badge — Image 6
            Positioned(top: 14, left: 14, child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: C.surface,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8)]),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 8, height: 8,
                  decoration: const BoxDecoration(color: C.green, shape: BoxShape.circle)),
                const SizedBox(width: 6),
                Text('LIVE NOW', style: TextStyle(
                  fontSize: context.fs(C.fCap), fontWeight: FontWeight.w800, color: C.green)),
              ]),
            )),
          ]),
        ),
      ),
      const SizedBox(height: 14),

      // Location label card — Image 6
      CC(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('CURRENT LOCATION', style: TextStyle(
            fontSize: context.fs(C.fCap), color: C.textMid,
            fontWeight: FontWeight.w700, letterSpacing: 1)),
          const SizedBox(height: 6),
          Text(m.locationLabel, style: TextStyle(
            fontSize: context.fs(C.fH2),
            fontWeight: FontWeight.w900, color: C.textDark)),
          const SizedBox(height: 4),
          Text('Updated ${DateTime.now().difference(m.lastSeen).inMinutes} mins ago',
            style: TextStyle(fontSize: context.fs(C.fSub), color: C.textMid)),
        ]),
      ),
    ],
  );
}

class _StrTab extends StatelessWidget {
  final MockFamilyMember m; final bool e;
  const _StrTab({required this.m, required this.e});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
    children: [
      // Circular streak — Image 7
      CC(
        pad: const EdgeInsets.symmetric(vertical: 36),
        child: Center(child: SizedBox(
          width: e ? 190 : 160, height: e ? 190 : 160,
          child: Stack(alignment: Alignment.center, children: [
            SizedBox.expand(child: CircularProgressIndicator(
              value: m.streakDays / 30,
              strokeWidth: 10,
              backgroundColor: C.divider,
              color: C.fire,
              strokeCap: StrokeCap.round,
            )),
            Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.local_fire_department_rounded,
                color: C.fire, size: e ? 38 : 32),
              Text('${m.streakDays}', style: TextStyle(
                fontSize: context.fs(e ? 56 : 48),
                fontWeight: FontWeight.w900, color: C.textDark, height: 1.0)),
              Text('DAYS', style: TextStyle(
                fontSize: context.fs(C.fSub), color: C.textMid,
                fontWeight: FontWeight.w700, letterSpacing: 1.5)),
            ]),
          ]),
        )),
      ),
      const SizedBox(height: 14),
      // Check-in status — Image 7
      CC(
        bg: m.checkedInToday ? C.greenSoft : C.orangeSoft,
        child: Row(children: [
          Icon(m.checkedInToday ? Icons.favorite_rounded : Icons.favorite_border_rounded,
            color: m.checkedInToday ? C.green : C.orange, size: e ? 26 : 22),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(m.checkedInToday ? 'Successfully Checked-in' : 'Not checked in yet',
              style: TextStyle(
                fontSize: context.fs(C.fBody),
                fontWeight: FontWeight.w900,
                color: m.checkedInToday ? C.green : C.orange)),
            const SizedBox(height: 2),
            Text(m.checkedInToday ? 'Everything looks great today!' : 'Waiting for check-in',
              style: TextStyle(fontSize: context.fs(C.fSub), color: C.textMid)),
          ])),
        ]),
      ),
    ],
  );
}

class _MedTab extends StatelessWidget {
  final MockFamilyMember m; final bool e;
  const _MedTab({required this.m, required this.e});

  @override
  Widget build(BuildContext context) {
    final taken = m.medicines.where((med) => med.takenToday).length;
    final pct = m.medicines.isEmpty ? 0.0 : taken / m.medicines.length;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      children: [
        // Header — Image 8
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text("TODAY'S ADHERENCE", style: TextStyle(
            fontSize: context.fs(C.fCap), fontWeight: FontWeight.w800,
            color: C.textMid, letterSpacing: 1)),
          Text('${(pct * 100).round()}%', style: TextStyle(
            fontSize: context.fs(C.fH2),
            fontWeight: FontWeight.w900,
            color: pct == 1 ? C.green : C.primary)),
        ]),
        const SizedBox(height: 14),
        // Med list
        CC(
          pad: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: m.medicines.asMap().entries.map((en) {
            final i = en.key;
            final med = en.value;
            return Column(children: [
              if (i > 0) const Divider(height: 1, indent: 16, endIndent: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(children: [
                  Container(
                    width: e ? 48 : 42, height: e ? 48 : 42,
                    decoration: BoxDecoration(
                      color: med.takenToday ? C.greenSoft : C.primarySoft,
                      borderRadius: BorderRadius.circular(12)),
                    child: Icon(Icons.medication_outlined,
                      color: med.takenToday ? C.green : C.primary,
                      size: context.ic)),
                  const SizedBox(width: 14),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(med.name, style: TextStyle(
                      fontSize: context.fs(C.fBody),
                      fontWeight: FontWeight.w800, color: C.textDark)),
                    const SizedBox(height: 2),
                    Text(med.time.format(context), style: TextStyle(
                      fontSize: context.fs(C.fSub), color: C.textMid)),
                  ])),
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: e ? 18 : 14, vertical: e ? 10 : 7),
                    decoration: BoxDecoration(
                      color: med.takenToday ? C.greenSoft : C.primarySoft,
                      borderRadius: BorderRadius.circular(20)),
                    child: Text(med.takenToday ? 'TAKEN' : 'PENDING',
                      style: TextStyle(
                        fontSize: context.fs(C.fCap),
                        fontWeight: FontWeight.w900,
                        color: med.takenToday ? C.green : C.primary,
                        letterSpacing: 0.5)),
                  ),
                ]),
              ),
            ]);
          }).toList()),
        ),
      ],
    );
  }
}

class _EvTab extends StatelessWidget {
  final MockFamilyMember m; final bool e;
  const _EvTab({required this.m, required this.e});

  @override
  Widget build(BuildContext context) {
    final mons = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      children: [
        Text('UPCOMING SCHEDULE', style: TextStyle(
          fontSize: context.fs(C.fCap), fontWeight: FontWeight.w800,
          color: C.textMid, letterSpacing: 1)),
        const SizedBox(height: 12),
        if (m.events.isEmpty)
          Center(child: Padding(padding: const EdgeInsets.all(40),
            child: Column(children: [
              Icon(Icons.event_busy_outlined, size: e ? 52 : 42, color: C.textLight),
              const SizedBox(height: 12),
              Text('No upcoming events', style: TextStyle(
                fontSize: context.fs(C.fBody), color: C.textMid)),
            ])))
        else
          ...m.events.map((ev) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: C.surface, borderRadius: BorderRadius.circular(14)),
            child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              // Date column — Image 9 style
              Column(children: [
                Text(mons[ev.dateTime.month - 1], style: TextStyle(
                  fontSize: context.fs(C.fCap), fontWeight: FontWeight.w800,
                  color: C.primary, letterSpacing: 1)),
                Text('${ev.dateTime.day}', style: TextStyle(
                  fontSize: context.fs(C.fTitle),
                  fontWeight: FontWeight.w900, color: C.textDark, height: 1.0)),
              ]),
              const SizedBox(width: 18),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(ev.title, style: TextStyle(
                  fontSize: context.fs(C.fBody),
                  fontWeight: FontWeight.w800, color: C.textDark)),
                const SizedBox(height: 3),
                Text(ev.location, style: TextStyle(
                  fontSize: context.fs(C.fSub), color: C.textMid)),
              ])),
            ]),
          )),
      ],
    );
  }
}