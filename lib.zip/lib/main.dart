// main.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'cc_theme.dart';
import 'services/auth_service.dart';
import 'services/firestore_service.dart';
import 'screens/auth/phone_screen.dart';
import 'cc_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  runApp(const AppRoot());
}

class AppRoot extends StatelessWidget {
  const AppRoot({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthService()),
        Provider(create: (_) => FirestoreService()),
      ],
      child: const _AppWrapper(),
    );
  }
}

class _AppWrapper extends StatefulWidget {
  const _AppWrapper();
  @override
  State<_AppWrapper> createState() => _AppWrapperState();
}

class _AppWrapperState extends State<_AppWrapper> {
  bool _elder = false;
  void _toggleElder(bool v) => setState(() => _elder = v);

  @override
  Widget build(BuildContext context) {
    return ElderScope(
      on: _elder,
      child: MaterialApp(
        title: 'CareCompanion',
        debugShowCheckedModeBanner: false,
        theme: C.theme,
        home: Consumer<AuthService>(
          builder: (_, auth, __) {
            switch (auth.status) {

              case AuthStatus.unknown:
              case AuthStatus.loading:
                // App starting or fetching profile — show splash
                return const _SplashScreen();

              case AuthStatus.authenticated:
                // Logged in + profile ready — show app
                return Shell(onToggleElder: _toggleElder);

              case AuthStatus.unauthenticated:
                // Not logged in — show phone screen
                return const PhoneScreen();
            }
          },
        ),
      ),
    );
  }
}

class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: C.bg,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 36,
              backgroundColor: C.primary,
              child: Icon(Icons.favorite_rounded,
                color: Colors.white, size: 32),
            ),
            SizedBox(height: 24),
            Text('CareCompanion', style: TextStyle(
              fontSize: C.fH2,
              fontWeight: FontWeight.w900,
              color: C.textDark)),
            SizedBox(height: 20),
            SizedBox(
              width: 24, height: 24,
              child: CircularProgressIndicator(
                color: C.primary, strokeWidth: 2.5)),
          ],
        ),
      ),
    );
  }
}