// cc_home.dart — pixel-accurate to Image 2
import 'package:flutter/material.dart';
import 'cc_theme.dart';
import 'models/mock_data.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _S();
}

class _S extends State<HomeTab> {
  int? _mood;
  final _moods = [('😄','GREAT'),('🙂','GOOD'),('😐','OKAY'),('😔','LOW'),('😢','SAD')];
  late List<bool> _taken;

  @override
  void initState() {
    super.initState();
    _taken = MockData.familyMembers[0].medicines.map((m) => m.takenToday).toList();
  }

  @override
  Widget build(BuildContext context) {
    final e = context.elder;
    final m = MockData.familyMembers[0];
    final h = DateTime.now().hour;
    final greet = h < 12 ? 'GOOD MORNING' : h < 17 ? 'GOOD AFTERNOON' : 'GOOD EVENING';

    return Scaffold(
      backgroundColor: C.bg,
      body: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          floating: false,
          backgroundColor: C.bg,
          elevation: 0,
          scrolledUnderElevation: 0,
          toolbarHeight: 72,
          titleSpacing: 20,
          title: Column(crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min, children: [
            Text(greet, style: TextStyle(
              fontSize: context.fs(C.fCap), color: C.primary,
              fontWeight: FontWeight.w800, letterSpacing: 1.2)),
            Text('Alex Henderson', style: TextStyle(
              fontSize: context.fs(C.fName),
              fontWeight: FontWeight.w900, color: C.textDark, height: 1.2)),
          ]),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Container(
                width: e ? 46 : 40, height: e ? 46 : 40,
                decoration: const BoxDecoration(color: C.surface, shape: BoxShape.circle),
                child: Icon(Icons.notifications_outlined, color: C.textMid, size: context.ic),
              ),
            ),
          ],
        ),

        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
          sliver: SliverList(delegate: SliverChildListDelegate([

            // ── Daily Streak card (purple soft bg) — Image 2
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: C.primarySoft,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(children: [
                Container(
                  width: e ? 52 : 46, height: e ? 52 : 46,
                  decoration: BoxDecoration(
                    color: C.surface,
                    borderRadius: BorderRadius.circular(14)),
                  child: Icon(Icons.local_fire_department_rounded,
                    color: C.fire, size: e ? 30 : 26),
                ),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Daily Streak', style: TextStyle(
                    fontSize: context.fs(C.fH2),
                    fontWeight: FontWeight.w900, color: C.textDark)),
                  Text('${m.streakDays} DAYS SAFE', style: TextStyle(
                    fontSize: context.fs(C.fCap), color: C.primary,
                    fontWeight: FontWeight.w800, letterSpacing: 1)),
                ])),
                Text('${m.streakDays}', style: TextStyle(
                  fontSize: context.fs(44),
                  fontWeight: FontWeight.w900, color: C.primary)),
              ]),
            ),

            const SizedBox(height: 22),
            const CapLabel('YOUR MOOD'),
            const SizedBox(height: 10),

            // ── Mood picker
            CC(
              pad: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: _moods.asMap().entries.map((en) {
                  final sel = _mood == en.key;
                  return GestureDetector(
                    onTap: () => setState(() => _mood = en.key),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      decoration: BoxDecoration(
                        color: sel ? C.primarySoft : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(en.value.$1, style: TextStyle(fontSize: e ? 30 : 24)),
                        const SizedBox(height: 5),
                        Text(en.value.$2, style: TextStyle(
                          fontSize: context.fs(C.fTiny),
                          fontWeight: sel ? FontWeight.w900 : FontWeight.w600,
                          color: sel ? C.primary : C.textLight,
                          letterSpacing: 0.5)),
                      ]),
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 22),

            // ── Medications header
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const CapLabel('MEDICATIONS'),
              Text('DETAILS', style: TextStyle(
                fontSize: context.fs(C.fCap), fontWeight: FontWeight.w800,
                color: C.primary, letterSpacing: 1.2)),
            ]),
            const SizedBox(height: 10),

            // ── Med list in single card with dividers — Image 2
            CC(
              pad: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: m.medicines.asMap().entries.map((en) {
                  final i = en.key;
                  final med = en.value;
                  final taken = _taken[i];
                  return Column(children: [
                    if (i > 0) const Divider(height: 1, indent: 16, endIndent: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      child: Row(children: [
                        Container(
                          width: e ? 48 : 42, height: e ? 48 : 42,
                          decoration: BoxDecoration(
                            color: taken ? C.greenSoft : C.primarySoft,
                            borderRadius: BorderRadius.circular(12)),
                          child: Icon(Icons.medication_outlined,
                            color: taken ? C.green : C.primary,
                            size: context.ic),
                        ),
                        const SizedBox(width: 14),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(med.name, style: TextStyle(
                            fontSize: context.fs(C.fBody),
                            fontWeight: FontWeight.w800, color: C.textDark)),
                          const SizedBox(height: 2),
                          Text('${med.dosage} · ${med.time.format(context)}',
                            style: TextStyle(
                              fontSize: context.fs(C.fSub), color: C.textMid)),
                        ])),
                        GestureDetector(
                          onTap: () => setState(() => _taken[i] = !_taken[i]),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            padding: EdgeInsets.symmetric(
                              horizontal: e ? 22 : 18,
                              vertical: e ? 12 : 9),
                            decoration: BoxDecoration(
                              color: taken ? C.green : C.primary,
                              borderRadius: BorderRadius.circular(20)),
                            child: Text(taken ? 'TAKEN' : 'TAKE',
                              style: TextStyle(
                                fontSize: context.fs(C.fCap),
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                letterSpacing: 0.5)),
                          ),
                        ),
                      ]),
                    ),
                  ]);
                }).toList(),
              ),
            ),

            const SizedBox(height: 22),

            // ── Emergency SOS — red rounded pill Image 2
            GestureDetector(
              onTap: () => _sos(context),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: e ? 20 : 16),
                decoration: BoxDecoration(
                  color: C.red,
                  borderRadius: BorderRadius.circular(16)),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.warning_amber_rounded,
                    color: Colors.white, size: e ? 28 : 24),
                  const SizedBox(width: 10),
                  Text('EMERGENCY SOS', style: TextStyle(
                    fontSize: context.fs(C.fH3),
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 1.5)),
                ]),
              ),
            ),
          ])),
        ),
      ]),
    );
  }

  void _sos(BuildContext ctx) => showDialog(
    context: ctx,
    builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      title: const Text('Send SOS?',
        style: TextStyle(fontWeight: FontWeight.w900, fontSize: C.fH2)),
      content: const Text(
        'This will immediately alert all your family members with your location.',
        style: TextStyle(fontSize: C.fBody)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancel', style: TextStyle(fontSize: C.fBody))),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(ctx);
            ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
              content: Text('SOS sent! Family alerted.'),
              behavior: SnackBarBehavior.floating));
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: C.red, foregroundColor: Colors.white,
            shape: const StadiumBorder()),
          child: const Text('Send SOS', style: TextStyle(fontSize: C.fBody))),
      ],
    ));
}