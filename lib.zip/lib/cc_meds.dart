// cc_meds.dart — pixel-accurate to Image 4
import 'package:flutter/material.dart';
import 'cc_theme.dart';
import 'models/mock_data.dart';

class MedsTab extends StatefulWidget {
  const MedsTab({super.key});
  @override
  State<MedsTab> createState() => _S();
}

class _S extends State<MedsTab> {
  late List<MockMedicine> _meds;
  @override
  void initState() {
    super.initState();
    _meds = List.from(MockData.familyMembers[0].medicines);
  }

  void _tog(int i) => setState(() => _meds[i] = MockMedicine(
    name: _meds[i].name, dosage: _meds[i].dosage,
    time: _meds[i].time, takenToday: !_meds[i].takenToday));

  @override
  Widget build(BuildContext context) {
    final e = context.elder;
    final taken = _meds.where((m) => m.takenToday).length;
    final pct = _meds.isEmpty ? 0.0 : taken / _meds.length;

    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 32),
          children: [
            // Header row — Image 4
            Row(crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Medicine', style: TextStyle(
                  fontSize: context.fs(C.fTitle),
                  fontWeight: FontWeight.w900, color: C.textDark)),
                Text('DAILY WELLNESS TRACKER', style: TextStyle(
                  fontSize: context.fs(C.fCap), color: C.textMid,
                  fontWeight: FontWeight.w800, letterSpacing: 1.2)),
              ]),
              GestureDetector(
                onTap: () => _showAdd(context),
                child: Container(
                  width: e ? 50 : 44, height: e ? 50 : 44,
                  decoration: BoxDecoration(
                    color: C.primary, borderRadius: BorderRadius.circular(14)),
                  child: Icon(Icons.add_rounded, color: Colors.white, size: e ? 28 : 24),
                ),
              ),
            ]),

            const SizedBox(height: 22),

            // Daily adherence card — Image 4
            CC(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Daily Adherence', style: TextStyle(
                      fontSize: context.fs(C.fBody),
                      fontWeight: FontWeight.w900, color: C.textDark)),
                    Text('${taken.toString().padLeft(1)} OF ${_meds.length} MEDS TAKEN',
                      style: TextStyle(
                        fontSize: context.fs(C.fCap), color: C.textMid,
                        fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                  ]),
                  Text('${(pct * 100).round()}%', style: TextStyle(
                    fontSize: context.fs(C.fTitle),
                    fontWeight: FontWeight.w900,
                    color: pct == 1 ? C.green : C.primary)),
                ]),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: pct,
                    backgroundColor: C.divider,
                    color: pct == 1 ? C.green : C.primary,
                    minHeight: e ? 10 : 8,
                  ),
                ),
              ]),
            ),

            const SizedBox(height: 22),
            const CapLabel("TODAY'S LIST"),
            const SizedBox(height: 10),

            // Med list — single card, dividers — Image 4
            CC(
              pad: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: _meds.asMap().entries.map((en) {
                  final i = en.key;
                  final med = en.value;
                  return Column(children: [
                    if (i > 0) const Divider(height: 1, indent: 16, endIndent: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      child: Row(children: [
                        Container(
                          width: e ? 50 : 44, height: e ? 50 : 44,
                          decoration: BoxDecoration(
                            color: med.takenToday ? C.greenSoft : C.primarySoft,
                            borderRadius: BorderRadius.circular(12)),
                          child: Icon(Icons.medication_outlined,
                            color: med.takenToday ? C.green : C.primary,
                            size: context.ic),
                        ),
                        const SizedBox(width: 14),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(med.name, style: TextStyle(
                            fontSize: context.fs(C.fBody),
                            fontWeight: FontWeight.w800, color: C.textDark)),
                          const SizedBox(height: 2),
                          Text('${med.dosage} · ${med.time.format(context)}',
                            style: TextStyle(
                              fontSize: context.fs(C.fSub), color: C.textMid)),
                        ])),
                        GestureDetector(
                          onTap: () => _tog(i),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            padding: EdgeInsets.symmetric(
                              horizontal: e ? 22 : 18,
                              vertical: e ? 12 : 9),
                            decoration: BoxDecoration(
                              color: med.takenToday ? C.green : C.primary,
                              borderRadius: BorderRadius.circular(20)),
                            child: Text(med.takenToday ? 'TAKEN' : 'TAKE',
                              style: TextStyle(
                                fontSize: context.fs(C.fCap),
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                letterSpacing: 0.5)),
                          ),
                        ),
                      ]),
                    ),
                  ]);
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAdd(BuildContext context) {
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: EdgeInsets.fromLTRB(22, 20, 22,
          MediaQuery.of(context).viewInsets.bottom + 32),
        decoration: const BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        child: Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 40, height: 4,
            decoration: BoxDecoration(color: C.divider,
              borderRadius: BorderRadius.circular(2)))),
          const SizedBox(height: 20),
          const Text('Add medicine', style: TextStyle(
            fontSize: C.fH2, fontWeight: FontWeight.w900, color: C.textDark)),
          const SizedBox(height: 20),
          const TextField(decoration: InputDecoration(
            labelText: 'Medicine name',
            border: OutlineInputBorder())),
          const SizedBox(height: 12),
          const TextField(decoration: InputDecoration(
            labelText: 'Dosage (e.g. 500mg)',
            border: OutlineInputBorder())),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity, height: 54,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: C.primary, foregroundColor: Colors.white,
                shape: const StadiumBorder()),
              child: const Text('Save', style: TextStyle(
                fontSize: C.fBody, fontWeight: FontWeight.w900)))),
        ]),
      ));
  }
}